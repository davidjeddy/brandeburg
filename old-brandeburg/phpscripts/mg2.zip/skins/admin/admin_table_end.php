</table>
<?php
if($controls==1){
?>
</form>
<?php } ?>
