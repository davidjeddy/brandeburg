<table class="table_actions" cellpadding="0" cellspacing="0">
<tr>
  <td class="td_status" align="center"><?php echo $this->status ?></td>
</tr>
</table>

