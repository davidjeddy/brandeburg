<table class="table_credits" cellpadding="0" cellspacing="0">
<tr>
  <td class="td_credits" align="center"><b>MG2</b> v<?php echo $mg2->version ?> <?php echo $mg2->lang['by'] ?> Thomas Rybak (<a href="http://www.minigal.dk" target="_blank">www.minigal.dk</a>)</td>
</tr>
</table>
