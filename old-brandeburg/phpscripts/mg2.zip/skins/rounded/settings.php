<?php
$skin_imagecolumns = "4";
$skin_imagerows = "3";
$skin_titlelimit = "55";
?>
