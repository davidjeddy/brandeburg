</tr>
</table>
<?php $mg2->pagenavigation($pages, $list); ?>
<?php if ($_REQUEST['list'] == "" || $_REQUEST['list'] == "1") { ?>
<div align="center"><a href="admin.php" target="_self"><img src="skins/admin/images/key.gif" width="13" height="7" alt="" title="" border="0" /></a></div>
<?php } ?>
<br />
</body>
</html>

