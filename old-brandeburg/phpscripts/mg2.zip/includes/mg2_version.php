<?php
$mg2->version = "0.5.1";
?>
